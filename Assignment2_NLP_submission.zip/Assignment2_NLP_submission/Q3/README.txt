To run the codes for Q3 follow the given steps:

For Q3.1:
	Opening 2 text files in different variables. Putting the file path will access the text file.
	The code executes and prints the accuracy.
For Q3.2:
	The 2 text files are opened using 2 variables. File path needs to be modified to access the files.
	The code executes and prints the accuracy.
For Q3.3:
	The 2 files are loaded in dofferent variables. File path needs to be modified to find the desired files.
	The code executes and prints the accuracy.
