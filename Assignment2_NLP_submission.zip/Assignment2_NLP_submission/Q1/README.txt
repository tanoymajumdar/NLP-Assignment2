This code takes in the file path in a variable to open and iterate through the text file.
The code executes and gives the desireables in a new file created Q1.txt.
